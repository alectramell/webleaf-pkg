#!/bin/bash

clear

gnome-terminal --title="Webleaf v1.0 | Updates.." -x sh -c "exec /usr/share/webleaf/update.sh" &

clear
