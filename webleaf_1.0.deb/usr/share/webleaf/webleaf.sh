#!/bin/bash
# Webleaf v1.0

clear

URLCH=$(zenity --width=200 --height=250 --list --column "" --title="Webleaf v1.0" --text="Please select your source.." \ "BrowserURL" \ "YouTube" \ "ShareRepo" \ "WebleafUpdate")

CHOICE=$(echo $URLCH.sh)

exec /usr/share/webleaf/$CHOICE

clear
