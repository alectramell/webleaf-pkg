#!/bin/bash

clear

WLURL=$(zenity --entry --title="Webleaf v1.0" --text="URL") && gnome-terminal --title="WebLeaf v1.0 | Download via YouTube.." -x sh -c "cd ~/Desktop/ && youtube-dl $WLURL" &

clear
