#!/bin/bash

clear

FURL=$(zenity --entry --title="Webleaf v1.0" --text="URL: ")

FNAM=$(zenity --entry --title="Webleaf v1.0" --text="SAVE-AS: ")

cd ~/Desktop/ && wget -b -c $FURL -O $FNAM -o ~/Desktop/webleaf.log

gnome-terminal --title="Webleaf v1.0 | Download via URL.." -x sh -c "clear && cd ~/Desktop && tail -f ~/Desktop/webleaf.log" &

clear
