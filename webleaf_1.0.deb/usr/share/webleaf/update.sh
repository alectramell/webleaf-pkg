#!/bin/bash

clear

BOOKS=$(cat /usr/share/webleaf/books.txt) && sudo apt-get -y install $BOOKS

UPINFO=$(zenity --info --title="Webleaf v1.0" --text="Update Complete!")

clear
